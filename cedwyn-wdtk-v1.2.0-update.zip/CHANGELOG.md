# Changelog

## [1.2.0] - 2026-11-24

### Added
- New request page: Ministry of Housing, Communities and Local Government, "Great House Farm, Llandough (Sir Herbert of Swansea to Vaughan)" (5 messages, 2 PDF attachments). The Department's two replies (20 and 23 November 2026, FOI2026/36329 and FOI2026/36556) are kept separate. WhatDoTheyKnow classification is pending, so the page applies none.

### Changed
- Llandough Community Council thread updated from 1 to 9 messages (a reply with an attached Word document on 11 November, whose contents are not summarised; holding acknowledgements on 17 and 18 November). Status changed from "awaiting response" to "delayed" to match WhatDoTheyKnow (due 17 November 2026). Copying-cost and file-description detail from the Clerk's reply is not repeated.
- Homepage totals refreshed to 24 November 2026: 8 requests, 56 messages (27 sent, 29 received, 14 acknowledgements), 20 attachments, 4 refusals (derived; includes the Ministry of Housing thread under the existing "refused to treat it as a request" definition).
- Deadlines gauge replaced by a descriptive timing count of 20 working day response dates: reply recorded in time for 5, no answer recorded by the due date for 3, not assessed for 2 (Llandough Community Council; Ministry of Housing, Communities and Local Government, where whether a clock started is disputed), not applicable for 1 (the NPCC first letter, an automated receipt). It makes no finding on validity or legal compliance. Internal review periods (reply within for 2, none or later for 3) are shown as guidance and The National Archives' promised date as a promise. Each thread's deadline entries now carry a type, and the static thread pages for MoJ, MoD, HMCTS, Vale, NPCC and TNA use the same descriptive wording.
- Correction: NPCC FOI 3203 (due 29 October 2026) was briefly listed as open in a draft of this release. The thread has no reply to it, so no answer is recorded by its due date. The earlier open/met/missed wording was replaced by descriptive timing labels.
- "Threads with a substantive reply" is now "Threads with a reply beyond acknowledgement" (6 of 8). It includes the Ministry of Housing validity decision, which the page says is not an answer about recorded information.
- 424 days waiting (total age of unanswered requests to 24 November 2026; not days past a deadline). Older 6 missed, seven-body and 254-day statements removed from the Llandough checkpoint; 254 is kept only as a dated earlier snapshot.

### Not refreshed
- Catalogue identifiers (WB/EV) and archived JSON copies are not assigned for the new thread.

### Validated
- The six other threads were checked against WhatDoTheyKnow on 24 November 2026: message counts unchanged.

## [1.0.2] - 2026-10-24

### Fixed
- Change the five-stat summary from five cramped columns to three columns on screens at or below 420px wide, improving readability on phones.
- Refresh the stylesheet cache key and synchronize the JSON index version.

### Validated
- Visible summary counts match the current machine-readable index: 7 requests, 3 refusals, 8 “not held”, 6 missed deadlines and 254 open days.
- No request thread content or status was changed.

